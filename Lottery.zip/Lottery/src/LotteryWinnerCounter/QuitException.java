package LotteryWinnerCounter;

public class QuitException extends Exception {
    public QuitException(String s) {
    }
  }
